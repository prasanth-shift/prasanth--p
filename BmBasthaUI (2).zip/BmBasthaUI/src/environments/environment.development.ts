export const environment = {
    production: true,
  serverUrl: 'http://150.242.203.100:5000',
};
