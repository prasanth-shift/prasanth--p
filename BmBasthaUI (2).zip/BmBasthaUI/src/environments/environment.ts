export const environment = {
  production: false,
  serverUrl: 'http://150.242.203.100:5000'
};
